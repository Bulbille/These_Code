#include "init.h"
#include "math.h"
#include "dynamique.h"
#include <gsl/gsl_histogram.h>

void parametres(int argc, char* argv[]);
void ecriture(int grille[][TAILLE_Y], long int temps, gsl_histogram histogramme,double magy[], double interface[], double ex[], double correl_x[][TAILLE_Y]);

double BETA;
double ttc = 1;
string prefix = ".";
string suffix = "";
double H=H0;

std::default_random_engine generator;

clock_t cputime = clock();


/****************** Main ******************/
int main(int argc, char *argv[]){

	int grille[TAILLE_X][TAILLE_Y], ppv[TAILLE_X][TAILLE_Y][4]; double liens_ppv[tot_liens][5];
	double delta_t=0,dt=0;
	generator.seed(time(NULL));
/********** OPTIONS DEPUIS LE BASH *********/
/* Le programme peut accepter deux options : */
/* --beta xxx */
/* --reprendre fichier */
/* La première option permet de faire la simulation avec une température donnée */
/* La deuxième permet de reprendre la simulation à partir d'un fichier */
/**/	parametres(argc,argv); /**/
/**/	generation(grille,ppv,liens_ppv,tot_liens,&delta_t); dt=1/delta_t;
/**/    ttc = static_cast<double>(static_cast<int>(ttc*1000))/1000;
/******************************************/

	/******* VARIABLES MICRO *********/
	gsl_histogram * histo = gsl_histogram_alloc (TAILLE_Y-1);
        gsl_histogram_set_ranges_uniform (histo, 0.1,TAILLE_Y-0.9);

	/**** VARIABLES INTERMÉDIAIRES *****/
	long int photo_suiv=0; int nb_photos=0;double donnee_suiv=0;

        double ex[TAILLE_Y];
        double correl_x[TAILLE_X][TAILLE_Y];
	double magy[TAILLE_Y]; for(int y=0;y<TAILLE_Y;y++){ magy[y]=0; ex[y]=0; for(int x=0;x<TAILLE_X;x++) correl_x[x][y]=0;}

	/********************************************/
	/****** DYNAMIQUE DE KAWASAKI ***************/
	/*******************************************/

	double Hprime = H;
	H = H0;
	for(double t = 0;t <= T_CHAMP; t+= dt){
		int tirage = tirage_lien(liens_ppv);
		int x1 = liens_ppv[tirage][0];
		int y1 = liens_ppv[tirage][1];
		int x2 = liens_ppv[tirage][2];
		int y2 = liens_ppv[tirage][3];
		grille[x1][y1] *= -1;
		grille[x2][y2] *= -1;
		maj_liens(grille, ppv, liens_ppv, &delta_t,tirage);
		dt=1/delta_t;
	}
	H=Hprime;
	double ndt=0;
	for(double t = 0; t<=T_MAX ; t+= dt){		
		/******************************************************/
		/*********** CALCULS GRANDEURS THERMO *****************/
		/** moyenne_n = moyenne_(n-1) * (n-1) / n + a_n / n ***/
		/******************************************************/

		int modulo_photo = static_cast<int>(modulo_d(dt+t,T_PHOTO));
                if(photo_suiv <= static_cast<int>(t) && modulo_photo == 0) {
                        photo_suiv += T_PHOTO; nb_photos++;
			// L'interface est par construction à TAILLE_X/2
//*
			double interface[TAILLE_X]; double ancien_interface = TAILLE_Y/2;
			for(int x=0;x<TAILLE_X;x++){
				int interfacem=1;int interfacep=TAILLE_Y-2;
				bool plusmoins=true; int iterations=0; 
				while(interfacep-interfacem > 1){
					if(plusmoins){
						if(grille[x][interfacem-1] == grille[x][interfacem] 
							&& grille[x][interfacem] != grille[x][interfacem+1] 
							&& grille[x][interfacem+1] == grille[x][interfacem+2]){
							plusmoins = !plusmoins;
							iterations++;
						}
						else
							interfacem++;
					}
					else{
						if(grille[x][interfacep-1] == grille[x][interfacep] 
							&& grille[x][interfacep] != grille[x][interfacep+1] 
							&& grille[x][interfacep+1] == grille[x][interfacep+2]){
							plusmoins = !plusmoins;
							iterations++;
						}
						else
							interfacep--;
					}
					if(iterations > 1) break;
				}
				interface[x]=(interfacem+interfacep)/2.;
				if((abs(interfacep-ancien_interface) >= 7 && abs(interfacem-ancien_interface) >= 7) || abs(interfacep-interfacem) > 2){ interface[x] = -1;  continue;}
				ancien_interface = (interfacem+interfacep)/2.;
				gsl_histogram_increment(histo,(ancien_interface));
			}//*/

                        /*** Grandeurs thermo vectorielles ***/
                        double p_magy[TAILLE_Y], p_ex[TAILLE_Y];
                        double p_correl_x[TAILLE_X][TAILLE_Y];
                        int n_correl[TAILLE_X][TAILLE_Y];
                        for(int y=0;y<TAILLE_Y;y++){
                                p_magy[y] = 0 ; p_ex[y] = 0; 
                                // Magnetisation et énergies de bandes
				   for(int x=0;x<TAILLE_X;x++){
                                        p_magy[y] += 1. * grille[x][y] / TAILLE_X;
                                        p_ex[y] -= 1. * grille[x][y] * grille[modulo(x+1,TAILLE_X)][y] / TAILLE_X;
                                        p_correl_x[x][y] = 0;
                                        n_correl[x][y] = 0;
                                }
			}
                        for(int y=0;y<TAILLE_Y;y++){
				for(int x=0;x<TAILLE_X;x++){
					for(int r=0;r<TAILLE_X;r++){
                                                p_correl_x[r][y] += 1.*grille[x][y]*grille[modulo(x+r,TAILLE_X)][y];
                                                n_correl[r][y]++;
                                        }
                                }
                                magy[y] = 1.*magy[y]*(nb_photos-1)/nb_photos+1.*p_magy[y]/nb_photos;
                                ex[y] = 1.*ex[y]*(nb_photos-1)/nb_photos+1.*p_ex[y]/nb_photos;
                                for(int x=0; x<TAILLE_X;x++){
                                        p_correl_x[x][y] = 1.*p_correl_x[x][y]/n_correl[x][y] - p_magy[y]*p_magy[y];
					correl_x[x][y] = 1.*correl_x[x][y]*(nb_photos-1)/nb_photos+1.*p_correl_x[x][y]/nb_photos;
                                }
                        }

			if(donnee_suiv <=static_cast<int>(t)){
				cout << t << " " << ndt/t <<" " << float(clock()-cputime)/CLOCKS_PER_SEC<< "\n";
				ecriture(grille,t,*histo,magy,interface,ex,correl_x);
                                donnee_suiv+=T_DONNEE;
                       } 
		}
		/****** MONTE CARLO STEP ****/
		int tirage,x1,y1,x2,y2; 
		tirage = tirage_lien(liens_ppv);
		x1 = liens_ppv[tirage][0];
		y1 = liens_ppv[tirage][1];
		x2 = liens_ppv[tirage][2];
		y2 = liens_ppv[tirage][3];
		grille[x1][y1] *= -1;
		grille[x2][y2] *= -1;
		maj_liens(grille, ppv, liens_ppv, &delta_t,tirage);
		dt = 1/delta_t;
		ndt++;

	}
/*************** FIN  **********************/
return 0;
}

/******* LECTURE DES PARAMÈTRES DU BASH **********/
void parametres(int argc, char* argv[]){
	BETA=1./T_C;
        if(argc > 1){ 
		for(int i = 1; i<argc; ++i){
			std::string arg = argv[i];
			if(arg == "--t"){
				if(isOnlyDouble(argv[i+1])){
					ttc = atof(argv[i+1]);
					BETA = 1/(ttc*T_C);
				}
				else{ cout << "Le paramètre temperature n'est pas un double"; abort();}
			}
			else if(arg == "--h"){
				if(isOnlyDouble(argv[i+1])){
					H = atof(argv[i+1]);
				}
				else{ cout << "Le paramètre h n'est pas un double"; abort();}
			}
			else if(arg == "--prefix"){
				prefix = argv[i+1];
			}
			else if(arg == "--suffix"){
				suffix = argv[i+1];
			}
		}
	}
}

/************* ÉCRITURE DANS FICHIER **********/
void ecriture(int grille[][TAILLE_Y], long int temps, gsl_histogram histogramme,double magy[], double interface[], double ex[],double correl[][TAILLE_Y]){

        /*********** CREATION DOSSIER POUR RESULTATS ********/

        if(system(("mkdir -p " + prefix).c_str())) {;}
        string str = to_string(ttc);
	str.erase ( str.find_last_not_of('0') + 1, std::string::npos );
        string algo = prefix + "/kaw_ttc_" + str + suffix; // + "-t" + to_string(0);
	if(fabs(H) > 1e-4){
		str = to_string(H);
		str.erase ( str.find_last_not_of('0') + 1, std::string::npos );
		algo += "-h-" + str;
	}

	/******* ÉCRITURES GRANDEURS THERMO ****/
        str = prefix + "/thermo_kaw" + suffix;
        ifstream test(str.c_str());
        ofstream thermo_res;
        if(static_cast<bool>(test)){
                thermo_res.open(str.c_str(), ios::out | ios::app);
        }
        else{
                thermo_res.open(str.c_str(), ios::out);
        }

        thermo_res << ttc << " " << H << " " << temps << " " << float(clock()-cputime)/CLOCKS_PER_SEC << "\n";
	thermo_res.close();

        /**** ECRITURE DANS FICHIER DERNIER ETAT DU RESEAU **/
        str = algo;
        ofstream result(str.c_str());
	str = algo+"-magy";
	ofstream fmagy(str.c_str());
	str = algo+"-energie";
	ofstream fenergie(str.c_str());
	str = algo+"-correl";
	ofstream fcorrel(str.c_str());

	for(int y=0; y<TAILLE_Y;y++)
	{
		fmagy << y << " " << magy[y] << "\n";
		fenergie << y << " " << ex[y] << "\n";
		for(int x=0; x<TAILLE_X;x++){
			result << x << " " << y << " " << grille[x][y] << "\n";
			fcorrel << x << " " << y << " " << correl[x][y] << "\n";
		}//*/
	}
	fmagy.close();
	result.close();
	fenergie.close();
	fcorrel.close();
	
        str = algo+"-histo";
        FILE* fhisto;
        fhisto = fopen(str.c_str(),"w");
        gsl_histogram_fprintf(fhisto,&histogramme, "%f","%f");
        fclose(fhisto);

	str = algo+"-interface";
	ofstream finter(str.c_str());
	for(int x=0;x<TAILLE_X;x++) {
		finter <<  interface[x] << "\n";
	}
	finter.close();
}

