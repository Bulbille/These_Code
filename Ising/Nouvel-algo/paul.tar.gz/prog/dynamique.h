#include "init.h"
#ifndef DYNAMIQUE
#define DYNAMIQUE

double exchange(int grille[][TAILLE_Y], int x1, int y1, int x2, int y2);
double hamil_loc(int grille[][TAILLE_Y],int x,int y);
double champ_mag(int x1, int y1);

void maj_liens(int grille[][TAILLE_Y], int ppv[][TAILLE_Y][4], double liens_ppv[][5], double* delta_t, int tirage);
int tirage_lien(double tableau[][5]);
void generation(int grille[][TAILLE_Y], int ppv[][TAILLE_Y][4], double liens_ppv[][5], int nb_liens, double* delta_t);

#endif
