#include "dynamique.h"
#include "math.h"
#include "init.h"

/************************************/
/*** EQUATIONS DE LA DYNAMIQUE ******/
/************************************/

double exchange(int grille[][TAILLE_Y], int x1, int y1, int x2, int y2){
	if( grille[x1][y1] == grille[x2][y2] || y1 <= 0 || y2 <= 0 || y1 >= TAILLE_Y-1 || y2 >= TAILLE_Y-1 ) 
		return 0;
        double h_1 = grille[modulo(x1+1,TAILLE_X)][y1]+grille[modulo(x1-1,TAILLE_X)][y1]+grille[x1][y1+1]+grille[x1][y1-1]-grille[x2][y2];
        double h_2 = grille[modulo(x2+1,TAILLE_X)][y2]+grille[modulo(x2-1,TAILLE_X)][y2]+grille[x2][y2+1]+grille[x2][y2-1]-grille[x1][y1];
        double delta_h = 2.*J*grille[x1][y1]*(h_1-h_2);

	delta_h += 2.*grille[x1][y1]*(champ_mag(x2,y2)-champ_mag(x1,y1));
        return ((exp(-BETA*delta_h) <1 ) ? exp(-BETA*delta_h) : 1);
}

double champ_mag(int x1,int y1){
	double h = (y1 < TAILLE_Y/2) ? -H/2. : H/2. ;
	return h;
}

/********** ÉNERGIE LOCALE *******/
double hamil_loc(int grille[][TAILLE_Y],int x,int y){
	x = modulo(x,TAILLE_X);
	y = modulo(y,TAILLE_Y);
        double energie = grille[modulo(x+1,TAILLE_X)][y]+grille[modulo(x-1,TAILLE_X)][y]+grille[x][modulo(y+1,TAILLE_Y)]+grille[x][modulo(y-1,TAILLE_Y)];
	energie += champ_mag(x,y);
        return -J*energie*grille[x][y];
}

/***********************************************/
/*** Mise à jour des liens et tirage au sort ***/
/***********************************************/
void maj_liens(int grille[][TAILLE_Y], int ppv[][TAILLE_Y][4], double liens_ppv[][5], double* delta_t, int tirage){
	int x1=liens_ppv[tirage][0], y1=liens_ppv[tirage][1],x2=liens_ppv[tirage][2],y2=liens_ppv[tirage][3];
	for(int i=0;i<4;i++){
		int id_lien = ppv[x1][y1][i];
		if(id_lien >= 0 ){
			int xp1=liens_ppv[id_lien][0],yp1=liens_ppv[id_lien][1],xp2=liens_ppv[id_lien][2],yp2=liens_ppv[id_lien][3];
			liens_ppv[id_lien][4] = exchange(grille,xp1,yp1,xp2,yp2);
		}
		id_lien = ppv[x2][y2][i];
		if(id_lien >= 0 ){
			int xp1=liens_ppv[id_lien][0],yp1=liens_ppv[id_lien][1],xp2=liens_ppv[id_lien][2],yp2=liens_ppv[id_lien][3];
			liens_ppv[id_lien][4] = exchange(grille,xp1,yp1,xp2,yp2);
		}
	}
	*delta_t = 0;
	for(int id=0;id<tot_liens;id++)
		*delta_t+=liens_ppv[id][4];
}

int tirage_lien(double tableau[][5]){
        double tableau2[tot_liens];
        tableau2[0] = tableau[0][4];
        for(int i=1;i<tot_liens;i++) tableau2[i] = tableau[i][4] + tableau2[i-1];
        
        std::uniform_real_distribution<double> rand_rate(0,tableau2[tot_liens-1]);
        double tirage = rand_rate(generator);
        int id = 0; int ifin = tot_liens-1;

        if(tirage < tableau2[0]) return 0;

        while(ifin-id > 1){
                if(tableau2[ifin] > tirage && tableau2[id] > tirage) break;
                int m = static_cast<int>((id+ifin)/2);
                if(tirage > tableau2[m]) id = m;
                else  ifin = m;
        }
        return ifin;
}

void generation(int grille[][TAILLE_Y], int ppv[][TAILLE_Y][4], double liens_ppv[][5], int nb_liens, double* delta_t){
	/************ Génération de la grille *********/
	for(int x=0;x<TAILLE_X;x++){
		for(int y=0;y<TAILLE_Y;y++){
			//Génération magnétisation strictement égale à 0
			//*/
			if(TAILLE_Y % 2 ==0){
				if(y>=TAILLE_Y/2)
					grille[x][y] = -1;
				else
					grille[x][y] = 1;
			}
			else{
				if(y>TAILLE_Y/2)
					grille[x][y] = -1;
				else if(y == TAILLE_Y/2 && x < TAILLE_X/2)
					grille[x][y] = -1;
				else
					grille[x][y] = 1;
			}//*/
		//	grille[x][y] = 1; if(x== 3 && y==2) grille[x][y] = -1;
		}
        }

	/*********** Initialisation des liens *******/
	int id_lien=0;
	for(int y=0;y<TAILLE_Y;y++){
		for(int x=0;x<TAILLE_X;x++){
			//En bas
			if(y>0){
				liens_ppv[id_lien][0]=x;
				liens_ppv[id_lien][1]=y;
				liens_ppv[id_lien][2]=x;
				liens_ppv[id_lien][3]=y-1;
				liens_ppv[id_lien][4]=exchange(grille,x,y,x,y-1);
				id_lien++;
			}
			// À droite
				liens_ppv[id_lien][0]=x;
				liens_ppv[id_lien][1]=y;
				liens_ppv[id_lien][2]=modulo(x+1,TAILLE_X);
				liens_ppv[id_lien][3]=y;
				liens_ppv[id_lien][4]=exchange(grille,x,y,modulo(x+1,TAILLE_X),y);
				id_lien++;
		}
	}
	/******* Listage des plus proches voisins de chaque spin *******/
	for(int x=0;x<TAILLE_X;x++){
		for(int y=0;y<TAILLE_Y;y++){
			ppv[x][y][0]=-1;
			ppv[x][y][1]=-1;
			ppv[x][y][2]=-1;
			ppv[x][y][3]=-1;
		}
	}
	*delta_t = 0;
	for(int id=0;id<nb_liens;id++){
		int x1=liens_ppv[id][0];
		int y1=liens_ppv[id][1];
		int x2=liens_ppv[id][2];
		int y2=liens_ppv[id][3];
		if(x2 == modulo(x1+1,TAILLE_X)){ //Lien qui va vers la droite
			ppv[x1][y1][0] = id;
			ppv[x2][y2][1] = id;
		}
		else if(x1 == modulo(x2+1,TAILLE_X) ){ //Lien qui va vers la gauche
			ppv[x1][y1][1] = id;
			ppv[x2][y2][0] = id;
		}
		else if(y2 < y1){ //Lien vers le bas
			ppv[x1][y1][2] = id;
			ppv[x2][y2][3] = id;
		}
		else{
			ppv[x1][y1][3] = id;
			ppv[x2][y2][2] = id;
		}
		*delta_t+=liens_ppv[id][4];
	}
}

