#include "init.h"
#ifndef MATHS
#define MATHS

int modulo(int a, int b);
double modulo_d(double a, int b);
bool isOnlyDouble(const char* str);

#endif
